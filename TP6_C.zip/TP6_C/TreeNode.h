#include <stdio.h>

typedef struct TreeNode_{
	int data;
	struct TreeNode* left;
	struct TreeNode* right;
	}TreeNode;
	
void newNode (TreeNode* racine, int valeur);
void insert (TreeNode* racine, int valeur);
void inorder (TreeNode* racine );
