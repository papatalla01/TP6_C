#include <stdio.h>

typedef struct ListNode_{
	int value;
	struct ListNode* suivant;
	}ListNode;

void insertEnd(ListNode* racine, int element);
void  insertBeginning(ListNode* racine, int element0);
void insertMiddle(ListNode* new, int element1);
void deleteNode(ListNode* racine, int element);
void printList(ListNode* racine);
int searchNode( ListNode* racine, int element);
