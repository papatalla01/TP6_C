#include <stdio.h>
#include "Listnode.h"

void insertEnd(ListNode* racine, int element){
	ListNode* new = (ListNode*)malloc(sizeof(ListNode));
	new->value = element;
	new->next = NULL;	
	if(racine == NULL){
		racine = new;
		}
	else{
		while(racine.next != NULL){
			racine = racine->next;
			}
		racine->next = new;
	}
	}
		
void  insertBeginning(ListNode* racine, int element){
	ListNode* new = (ListNode*)malloc(sizeof(ListNode));
	new->value = element;
	new->next = racine;
	racine = new;
	}

void insertMiddle(ListNode* new, int element){
	ListNode* new1 = (ListNode*)malloc(sizeof(ListNode));
	new1->value = element;
	new1->next = new;
	new = new1;
	}
	
void deleteNode(ListNode* racine, int element){
	ListNode* precedent = NULL;
	
	//recherche du noeud a supprimer 
	while(racine != NULL & racine->value != element){
		precedent = racine; 
		racine = racine->next;
		}
	//suprression du noeud
	if(precedent == NULL){
		racine = racine->next;
		}
	else{
		precedent_>next = racine->next;
		}

void printList(ListNode* racine){
	ListNode* val = racine	
	
	while(val  != NULL){
		printf("%d", val->value);
		}
		val = val->next;
	printf("NULL\n");
	}
	
int searchNode( ListNode* racine, int element){
	ListNode* val = racine;
	int position = 1; 
	
	while(val != NULL){
		if(val->value == element){
			return position; 
		}
		val = val->next;
		position++;
		}
	return -1;
	printf("la valeur n'a pas été trouvée.\n");
	}
	
			
int main(){
	ListNode* racine = (ListNode*)malloc(sizeof(ListNode));
	racine->value = 0;
	racine->next = NULL;
	
	insertEnd(racine,1);
	insertEnd(racine,2);
	
	printf("Liste d'éléments: ");
	printlist(racine);
	
	
	 
	return 0;
	}
