#include <stdio.h>
#include <stdlib.h>
#include "TreeNode.h"

void newNode (TreeNode* racine, int valeur){
	struct TreeNode* new = (TreeNode*)malloc(sizeof(TreeNode));
	new->data = valeur;
	new->left = NULL;
	new->right = NULL;
	racine = new;
	}
	
void insert (TreeNode* racine, int valeur){
	if (racine == NULL){
		racine = newNode(valeur);
		return;
	}
	
	if (valeur < racine->data){
		racine->left = insert(racine->left, valeur);
		}
	else if (valeur >= racine->valeur){
		racine->right = insert(racine->right, valeur);
		}
		
void inorder (TreeNode* racine ){
	if(racine != NULL){
		inorder(racine->left);
		printf("%d", racine->data);
		inorder(racine->right)
		 }
	}
		
	
int main(){
	 TreeNode* racine = (TreeNode*)malloc(sizeof(TreeNode));
	 racine->data = 0;
	 racine->left = NULL;
	 racine->right = NULL;
	 
	 insert(&racine, 30);
	 insert(&racine, 40);
	 insert(&racine, 20);
	 insert(&racine, 10);
	 insert(&racine, 50);
	 insert(&racine, 25);
	 
	 printf ("Inorder: ");
	 inorder(racine);
	 printf("\n");
	 
	 free(racine);
	 
	 return 0;
	 }
